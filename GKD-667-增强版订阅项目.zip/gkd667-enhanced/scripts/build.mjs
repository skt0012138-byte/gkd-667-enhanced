import fs from 'node:fs/promises';
import path from 'node:path';
import JSON5 from 'json5';

const upstreamUrl =
  'https://raw.githubusercontent.com/Lin-arm/GKD_subscription/main/dist/gkd.json5';

const response = await fetch(upstreamUrl, {
  headers: { 'User-Agent': 'GKD-667-Enhanced-Subscription' },
});

if (!response.ok) {
  throw new Error(`下载上游订阅失败：HTTP ${response.status}`);
}

const sourceText = await response.text();
const subscription = JSON5.parse(sourceText);

if (!subscription || typeof subscription !== 'object' || !Array.isArray(subscription.categories)) {
  throw new Error('上游订阅格式异常：找不到 categories 数组，已停止生成以避免输出损坏文件。');
}

// 仅调整分类默认开关；apps、globalGroups 和规则内容全部沿用上游。
const enabledCategories = new Set([
  '开屏广告',
  '青少年模式',
  '更新提示',
  '评价提示',
  '通知提示',
  '局部广告',
  '全屏广告',
  '分段广告',
]);

const protectedOffCategories = new Set([
  '权限提示',
  '功能类',
  '其他',
]);

let changedCategories = 0;
for (const category of subscription.categories) {
  if (!category || typeof category.name !== 'string') continue;

  let shouldEnable = enabledCategories.has(category.name);
  if (protectedOffCategories.has(category.name)) shouldEnable = false;

  if (category.enable !== shouldEnable) changedCategories++;
  category.enable = shouldEnable;
}

// 使用独立订阅 ID，避免与原版 667 订阅混淆。
subscription.id = 667001;
subscription.name = 'GKD 667 增强版';
subscription.author = '667 Enhanced Community Build';

const repository = process.env.GITHUB_REPOSITORY;
if (!repository || !repository.includes('/')) {
  throw new Error('缺少 GITHUB_REPOSITORY 环境变量。请通过 GitHub Actions 运行此构建。');
}

const subscriptionUrl =
  `https://raw.githubusercontent.com/${repository}/main/dist/gkd.json5`;

subscription.updateUrl = subscriptionUrl;
subscription.checkUpdateUrl = subscriptionUrl;

const output = `${JSON.stringify(subscription, null, 2)}\n`;
const outputPath = path.resolve('dist/gkd.json5');

await fs.mkdir(path.dirname(outputPath), { recursive: true });
await fs.writeFile(outputPath, output, 'utf8');

console.log(`已生成：${outputPath}`);
console.log(`应用规则数量：${Array.isArray(subscription.apps) ? subscription.apps.length : '未知'}`);
console.log(`分类数量：${subscription.categories.length}`);
console.log(`本次调整默认开关的分类数：${changedCategories}`);
console.log(`订阅地址：${subscriptionUrl}`);
