# GKD 667 增强版订阅

这是一个基于 [Lin-arm/GKD_subscription](https://github.com/Lin-arm/GKD_subscription) 的个人增强构建。

## 做了什么

- 完整下载上游 `dist/gkd.json5`，保留全部应用、全局规则和规则组。
- 只修改分类默认开关，不改写具体规则。
- 使用独立订阅 ID `667001`，避免与原版订阅混淆。
- GitHub Actions 每天自动同步上游并生成 `dist/gkd.json5`，也可手动运行。

## 默认开启策略

默认开启：
- 开屏广告
- 青少年模式
- 更新提示
- 评价提示
- 通知提示
- 局部广告
- 全屏广告
- 分段广告

默认关闭：
- 权限提示
- 功能类
- 其他

注意：开启更多类别可能增加无障碍规则匹配、耗电和误触风险。尤其是青少年模式、通知提示等规则，建议首次使用时观察实际行为；如有不符合预期的动作，可在 GKD 的「规则类别」中关闭对应类别。

## 部署方法（手机也可以）

1. 在 GitHub 新建一个**公开（Public）**仓库，例如 `gkd-667-enhanced`。
2. 将本项目文件上传到仓库，保持目录结构：
   - `package.json`
   - `README.md`
   - `scripts/build.mjs`
   - `.github/workflows/update.yml`
3. 打开仓库的 **Actions** 标签页。
4. 如果提示需要启用 Actions，先启用。
5. 进入 `Sync and build GKD 667 Enhanced` 工作流，点击 **Run workflow**。
6. 等待运行成功。成功后仓库会出现 `dist/gkd.json5`。

## GKD 导入地址

将下面地址中的 `你的用户名/仓库名` 换成自己的 GitHub 用户名和仓库名：

```text
https://raw.githubusercontent.com/你的用户名/仓库名/main/dist/gkd.json5
```

例如仓库是 `abc/gkd-667-enhanced`，地址就是：

```text
https://raw.githubusercontent.com/abc/gkd-667-enhanced/main/dist/gkd.json5
```

## 更新机制

工作流每天北京时间 03:00 同步上游。也可以在 GitHub Actions 中手动运行。
如果上游订阅格式发生变化，构建会报错并停止提交，不会用不完整数据覆盖现有订阅。

## 免责声明

本项目仅调整订阅分类的默认启用状态，不保证所有应用规则在所有版本和设备上都适用。请按需使用，并在首次启用后检查规则行为。
